# push_swap_tester
## install check_mac from intra after that use tester
## push_swap
 argument 1 in tester is how many test you want
 argumnet 2 range number you want test(negative and positive number)

example ==> ./tester_push_swap 50 5
